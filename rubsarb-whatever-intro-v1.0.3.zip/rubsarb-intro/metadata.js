// Read YouTube's public player metadata in its own JavaScript world.
(() => {
  function publish() {
    if (location.pathname !== "/watch") return;
    const id = new URL(location.href).searchParams.get("v");
    const player = document.getElementById("movie_player");
    try {
      const details = player?.getPlayerResponse?.()?.videoDetails;
      // YouTube can retain the previous response during in-page navigation.
      if (details?.videoId !== id || !details.channelId) return;
      document.dispatchEvent(new CustomEvent("rubsarb-intro:metadata", {
        detail: JSON.stringify({ videoId: id, channelId: details.channelId })
      }));
    } catch { /* Try again while YouTube is initializing. */ }
  }
  setInterval(publish, 100);
})();
